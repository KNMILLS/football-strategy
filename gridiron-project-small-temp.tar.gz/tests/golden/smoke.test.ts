import { describe, it, expect } from 'vitest';

describe('project setup', () => {
  it('runs vitest', () => {
    expect(1 + 1).toBe(2);
  });
});


