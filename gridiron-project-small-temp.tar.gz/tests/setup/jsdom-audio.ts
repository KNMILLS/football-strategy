// Provide minimal WebAudio stubs so runtime can run in jsdom without AudioContext

class FakeAudioParam {
  value = 0;
  setValueAtTime(_v: number, _t: number) {}
  linearRampToValueAtTime(_v: number, _t: number) {}
  exponentialRampToValueAtTime(_v: number, _t: number) {}
}

class FakeNode {
  connect() { return this; }
  disconnect() {}
}

class FakeOscillatorNode extends FakeNode {
  type = 'sine';
  frequency = new FakeAudioParam();
  start() {}
  stop() {}
}

class FakeGainNode extends FakeNode {
  gain = new FakeAudioParam();
}

class FakeBiquadFilterNode extends FakeNode {
  type = 'lowpass';
  frequency = new FakeAudioParam();
}

class FakeDelayNode extends FakeNode {
  delayTime = new FakeAudioParam();
}

class FakeAudioBuffer {
  getChannelData() { return new Float32Array(0); }
}

class FakeAudioBufferSourceNode extends FakeNode {
  buffer: FakeAudioBuffer | null = null;
  start() { /* no-op */ }
  stop() { /* no-op */ }
}

class FakeAudioContext {
  currentTime = 0;
  destination = new FakeNode();
  sampleRate = 44100;
  createGain() { return new FakeGainNode(); }
  createOscillator() { return new FakeOscillatorNode(); }
  createBiquadFilter() { return new FakeBiquadFilterNode(); }
  createDelay() { return new FakeDelayNode(); }
  createConvolver() { return new FakeNode(); }
  createDynamicsCompressor() { return new FakeNode(); }
  createWaveShaper() { return new FakeNode(); }
  createBuffer(_c: number, _l: number, _sr: number) { return new FakeAudioBuffer(); }
  createBufferSource() { return new FakeAudioBufferSourceNode(); }
}

// Attach to globalThis for Vitest and jsdom
// @ts-expect-error jsdom environment
globalThis.AudioContext = FakeAudioContext;
// @ts-expect-error jsdom environment
globalThis.webkitAudioContext = FakeAudioContext;


