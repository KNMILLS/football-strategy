// Shared AI types to avoid circular dependencies
export type { PlayerTendenciesMemory } from './tendencies/PlayerTendenciesMemory';
