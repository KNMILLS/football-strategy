// Minimal stub for legacy animator preloading under Vite
export function noop() {}
export default { noop };
